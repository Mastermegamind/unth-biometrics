﻿Imports MySql.Data.MySqlClient
Imports System.IO

Public Class verificationform

    Dim mysqlconn As MySqlConnection
    Dim dr As MySqlDataReader
    Dim cmd As MySqlCommand

    Sub OnComplete(ByVal Control As Object, ByVal FeatureSet As DPFP.FeatureSet, ByRef EventHandlerStatus As DPFP.Gui.EventHandlerStatus) Handles VerificationControl.OnComplete
        If Me.InvokeRequired Then
            Dim status As DPFP.Gui.EventHandlerStatus = EventHandlerStatus
            Me.Invoke(Sub()
                          HandleVerification(FeatureSet, status)
                      End Sub)
            EventHandlerStatus = status
        Else
            HandleVerification(FeatureSet, EventHandlerStatus)
        End If
    End Sub

    Private Sub HandleVerification(ByVal FeatureSet As DPFP.FeatureSet, ByRef EventHandlerStatus As DPFP.Gui.EventHandlerStatus)
        Dim ver As New DPFP.Verification.Verification()
        Dim res As New DPFP.Verification.Verification.Result()
        Dim plo As Integer = 0

        For Each template As DPFP.Template In fptemplist   ' Compare feature set with all stored templates:
            If Not template Is Nothing Then                     '   Get template from storage.
                ver.Verify(FeatureSet, template, res)           '   Compare feature set with particular template.
                FalseAcceptRate.Text = res.FARAchieved.ToString          '   Determine the current False Accept Rate
                If res.Verified Then
                    EventHandlerStatus = DPFP.Gui.EventHandlerStatus.Success
                    PictureBox2.Image = My.Resources.check_mark_symbol_transparent_background_22
                    Dim name As String = listofnames(plo)
                    TextBox1.Text = listofnames(plo)
                    autoselect(name)
                    TimeIn()
                    Exit For ' success
                End If
            End If

            plo += 1
        Next
        If Not res.Verified Then
            EventHandlerStatus = DPFP.Gui.EventHandlerStatus.Failure
            PictureBox2.Image = My.Resources.question_mark_PNG66
            TextBox1.Text = ""
            txtName.Text = ""
        End If
    End Sub

    Sub autoselect(ByVal identity As String)
        Try
            Dim name As String = ""
            Using mysqlconn As New MySqlConnection(Module1.ConnectionString)
                Using cmd As New MySqlCommand("SELECT name, passport FROM students WHERE matricno = @matricno", mysqlconn)
                    cmd.Parameters.AddWithValue("@matricno", identity.Trim())
                    mysqlconn.Open()
                    Using dr As MySqlDataReader = cmd.ExecuteReader()
                        If dr.Read() Then
                            name = dr("name").ToString()
                            If Not dr.IsDBNull(dr.GetOrdinal("passport")) Then
                                Dim pByte As Byte() = CType(dr("passport"), Byte())
                                Using ms As New MemoryStream(pByte)
                                    PictureBox1.Image = New Bitmap(ms)
                                End Using
                            Else
                                PictureBox1.Image = Nothing
                            End If
                        End If
                    End Using
                End Using
            End Using
            If String.IsNullOrWhiteSpace(name) Then
                name = "No Name"
            End If

            Invoke(New FunctionCall(AddressOf setname), name)

        Catch ex As MySqlException
            MsgBox(ex.ToString, MsgBoxStyle.Exclamation, "")
        End Try


    End Sub

    'Private Sub setjobtitle(ByVal jobtitle As String)
    '    TextBox2.Text = jobtitle
    'End Sub

    Private Sub setname(ByVal name As String)
        txtName.Text = name
    End Sub
    Public Sub TimeIn()
        Try
            Dim attendanceDate As Date = DateClockIn.Value.Date
            Dim timeInValue As TimeSpan = DateTime.Now.TimeOfDay

            Using cnn As New MySqlConnection(Module1.ConnectionString)
                Using com As New MySqlCommand("SELECT 1 FROM attendance WHERE matricno = @matricno AND date = @date LIMIT 1", cnn)
                    com.CommandType = CommandType.Text
                    com.Parameters.AddWithValue("@matricno", TextBox1.Text.Trim())
                    com.Parameters.AddWithValue("@date", attendanceDate)
                    cnn.Open()
                    Dim exists As Object = com.ExecuteScalar()
                    If exists IsNot Nothing Then
                        Return
                    End If
                End Using
            End Using

            Using cn As New MySqlConnection(Module1.ConnectionString)
                Using comd As New MySqlCommand("INSERT INTO attendance (matricno, name, date, day, timein, timeout) VALUES (@matricno, @name, @date, @day, @timein, @timeout)", cn)
                    comd.CommandType = CommandType.Text
                    comd.Parameters.AddWithValue("@matricno", TextBox1.Text.Trim())
                    comd.Parameters.AddWithValue("@name", txtName.Text.Trim())
                    comd.Parameters.AddWithValue("@date", attendanceDate)
                    comd.Parameters.AddWithValue("@day", attendanceDate.ToString("dddd"))
                    comd.Parameters.AddWithValue("@timein", timeInValue)
                    comd.Parameters.AddWithValue("@timeout", DBNull.Value)
                    cn.Open()
                    comd.ExecuteNonQuery()
                End Using
            End Using

            ListView1.Items.Clear()
            BackgroundWorker1.RunWorkerAsync()

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub
    'Public Sub Reset()
    '    TextBox1.Text = Nothing
    '    'TextBox2.Text = Nothing
    '    txtName.Text = Nothing
    '    PictureBox1.Image = My.Resources.photo
    'End Sub

    Private Sub CloseButton_Click(sender As System.Object, e As System.EventArgs)
        Me.Close()
    End Sub

    Private Sub verificationform_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
    End Sub

    Private Sub BackgroundWorker1_DoWork(sender As System.Object, e As System.ComponentModel.DoWorkEventArgs) Handles BackgroundWorker1.DoWork
        Dim results As New List(Of String())()

        Try
            Using mysqlconn As New MySqlConnection(Module1.ConnectionString)
                Using cmd As New MySqlCommand("SELECT matricno, name, date, day, timein, timeout FROM attendance WHERE date = @date", mysqlconn)
                    cmd.Parameters.AddWithValue("@date", DateClockIn.Value.Date)
                    mysqlconn.Open()
                    Using sqlReader As MySqlDataReader = cmd.ExecuteReader()
                        While sqlReader.Read()
                            results.Add(New String() {
                                sqlReader("matricno").ToString(),
                                sqlReader("name").ToString(),
                                sqlReader("date").ToString(),
                                sqlReader("day").ToString(),
                                sqlReader("timein").ToString(),
                                sqlReader("timeout").ToString()
                            })
                        End While
                    End Using
                End Using
            End Using
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try

        Me.Invoke(Sub()
                      ListView1.BeginUpdate()
                      ListView1.Items.Clear()
                      For Each row In results
                          Dim li As ListViewItem = ListView1.Items.Add(row(0))
                          li.SubItems.Add(row(1))
                          li.SubItems.Add(row(2))
                          li.SubItems.Add(row(3))
                          li.SubItems.Add(row(4))
                          li.SubItems.Add(row(5))
                          If li.Index Mod 3 = 0 Then
                              li.BackColor = Color.LightBlue
                          End If
                      Next
                      ListView1.EndUpdate()
                      Label4.Text = ListView1.Items.Count.ToString()
                  End Sub)
    End Sub

    Public Sub verificationform_Shown(sender As Object, e As System.EventArgs) Handles Me.Shown
        BackgroundWorker1.RunWorkerAsync()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs)
        Me.Close()
    End Sub
    Public Sub Reset()
        TextBox1.Text = Nothing
        txtName.Text = Nothing
        PictureBox1.Image = Nothing
    End Sub

End Class
