Imports MySql.Data.MySqlClient
Imports System.Configuration

Module Module1
    Public fptemplist As New List(Of DPFP.Template)
    Public listofnames As New List(Of String)
    Delegate Sub FunctionCall(ByVal param)
    Delegate Sub FunctionCall2(ByVal param, ByVal param)

    Public report1datatable As New DataTable
    Public report1source As New DataSet
    Public nameemodule As String

    Public date1 As String
    Public date2 As String

    Private ReadOnly DefaultConnectionString As String = "SERVER=localhost; DATABASE=marvbiometric_student; userid=root; PASSWORD=; PORT=3306;"

    Public ReadOnly Property ConnectionString As String
        Get
            Dim cs = ConfigurationManager.ConnectionStrings("MarvBiometric")
            If cs IsNot Nothing AndAlso Not String.IsNullOrWhiteSpace(cs.ConnectionString) Then
                Return cs.ConnectionString
            End If
            Return DefaultConnectionString
        End Get
    End Property

    Public ReadOnly con As New MySqlConnection(ConnectionString)
End Module
