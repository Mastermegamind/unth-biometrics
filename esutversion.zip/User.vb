﻿Imports MySql.Data.MySqlClient
Public Class User
    Sub loadenrolleddata()
        Dim drt As MySqlDataReader
        Dim nm As String
        fptemplist.Clear()
        listofnames.Clear()
        Using mysqlconn As New MySqlConnection(Module1.ConnectionString)
            mysqlconn.Open()
            nm = "select matricno,fingerdata1,fingerdata2,fingerdata3,fingerdata4,fingerdata5,fingerdata6,fingerdata7,fingerdata8," _
                & "fingerdata9,fingerdata10 from new_enrollment"

            Using cmd As New MySqlCommand(nm, mysqlconn)
                drt = cmd.ExecuteReader
                While drt.Read()
                    For i = 1 To 10
                        Dim value As Object = drt("fingerdata" & i)
                        If value IsNot DBNull.Value Then
                            Dim fpbytes As Byte() = CType(value, Byte())
                            If fpbytes.Length > 0 Then
                                Dim mstram As New IO.MemoryStream(fpbytes)
                                Dim temp8 As DPFP.Template = New DPFP.Template
                                temp8.DeSerialize(mstram)
                                fptemplist.Add(temp8)
                                listofnames.Add(drt("matricno").ToString())
                            End If
                        End If
                    Next
                End While
                drt.Close()
            End Using
        End Using
    End Sub

    Private Sub User_Shown(sender As Object, e As System.EventArgs) Handles Me.Shown
        loadenrolleddata()
    End Sub
    Private Sub verificationToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles verificationToolStripMenuItem1.Click
        'verificationform.Close()
        'verificationform.ShowDialog()
    End Sub

    Private Sub LogoutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles LogoutToolStripMenuItem.Click
        Me.Close()
        Dim login As New Login()
        login.Show()
    End Sub

    Private Sub TimeInToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles TimeInToolStripMenuItem.Click
        verificationform.Close()
        verificationform.ShowDialog()
    End Sub

    Private Sub TimeOutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles TimeOutToolStripMenuItem.Click
        TimeOut.Close()
        TimeOut.ShowDialog()
    End Sub

    Private Sub User_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class
