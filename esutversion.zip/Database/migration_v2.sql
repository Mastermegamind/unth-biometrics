-- Migration for schema hardening and type fixes.
-- Suggested least-privilege user:
-- CREATE USER 'app_user'@'localhost' IDENTIFIED BY 'change_me';
-- GRANT SELECT, INSERT, UPDATE, DELETE ON marvbiometric_student.* TO 'app_user'@'localhost';

UPDATE `attendance`
SET `date` = STR_TO_DATE(`date`, '%d/%m/%Y')
WHERE `date` LIKE '%/%/%';

UPDATE `attendance`
SET `timein` = STR_TO_DATE(`timein`, '%H:%i')
WHERE `timein` LIKE '%:%';

UPDATE `attendance`
SET `timeout` = STR_TO_DATE(`timeout`, '%H:%i')
WHERE `timeout` LIKE '%:%';

ALTER TABLE `attendance`
  MODIFY `date` DATE NOT NULL,
  MODIFY `day` VARCHAR(20) NOT NULL,
  MODIFY `timein` TIME NOT NULL,
  MODIFY `timeout` TIME NULL;

ALTER TABLE `new_enrollment`
  MODIFY `fingerdata` LONGBLOB NULL,
  MODIFY `fingerdata1` LONGBLOB NULL,
  MODIFY `fingerdata2` LONGBLOB NULL,
  MODIFY `fingerdata3` LONGBLOB NULL,
  MODIFY `fingerdata4` LONGBLOB NULL,
  MODIFY `fingerdata5` LONGBLOB NULL,
  MODIFY `fingerdata6` LONGBLOB NULL,
  MODIFY `fingerdata7` LONGBLOB NULL,
  MODIFY `fingerdata8` LONGBLOB NULL,
  MODIFY `fingerdata9` LONGBLOB NULL,
  MODIFY `fingerdata10` LONGBLOB NULL,
  MODIFY `fingermask` INT NULL;

ALTER TABLE `registration`
  MODIFY `password` VARCHAR(255) NOT NULL;

ALTER TABLE `students`
  ADD UNIQUE KEY `matricno_unique` (`matricno`);

ALTER TABLE `registration`
  ADD UNIQUE KEY `username_unique` (`username`),
  ADD UNIQUE KEY `email_unique` (`email`);

ALTER TABLE `attendance`
  ADD UNIQUE KEY `matricno_date` (`matricno`, `date`);
