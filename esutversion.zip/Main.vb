﻿Imports MySql.Data.MySqlClient
Public Class Main
    Dim mysqlconn As MySqlConnection
    Dim dr As MySqlDataReader
    Dim cmd As MySqlCommand
    Private Sub Main_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Sub loadenrolleddata()
        Dim drt As MySqlDataReader
        Dim nm As String
        fptemplist.Clear()
        listofnames.Clear()
        Using mysqlconn As New MySqlConnection(Module1.ConnectionString)
            mysqlconn.Open()
            nm = "select matricno,fingerdata1,fingerdata2,fingerdata3,fingerdata4,fingerdata5,fingerdata6,fingerdata7,fingerdata8," _
                & "fingerdata9,fingerdata10 from new_enrollment"

            Using cmd As New MySqlCommand(nm, mysqlconn)
                drt = cmd.ExecuteReader
                While drt.Read()
                    For i = 1 To 10
                        Dim value As Object = drt("fingerdata" & i)
                        If value IsNot DBNull.Value Then
                            Dim fpbytes As Byte() = CType(value, Byte())
                            If fpbytes.Length > 0 Then
                                Dim mstram As New IO.MemoryStream(fpbytes)
                                Dim temp8 As DPFP.Template = New DPFP.Template
                                temp8.DeSerialize(mstram)
                                fptemplist.Add(temp8)
                                listofnames.Add(drt("matricno").ToString())
                            End If
                        End If
                    Next
                End While
                drt.Close()
            End Using
        End Using
    End Sub

    Private Sub Main_Shown(sender As Object, e As System.EventArgs) Handles Me.Shown
        loadenrolleddata()
    End Sub

    Private Sub RegistrationToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles RegistrationToolStripMenuItem.Click
        Dim register As New Register()
        register.Show()
    End Sub

    Private Sub EnrollmentMenuItem1_Click(sender As Object, e As EventArgs) Handles EnrollmentMenuItem1.Click
        Form1.Close()
        Form1.ShowDialog()
    End Sub

    Private Sub LogoutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles LogoutToolStripMenuItem.Click
        Me.Close()
        Dim login As New Login()
        login.Show()
    End Sub

    Private Sub verificationToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles verificationToolStripMenuItem1.Click

    End Sub

    Private Sub AddUserToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AddUserToolStripMenuItem.Click
        AdminReg.Close()
        AdminReg.ShowDialog()
    End Sub

    Private Sub ClockInToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ClockInToolStripMenuItem.Click
        verificationform.Close()
        verificationform.ShowDialog()
    End Sub

    Private Sub ClockOutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ClockOutToolStripMenuItem.Click
        TimeOut.Close()
        TimeOut.ShowDialog()
    End Sub

    Private Sub AttendanceReportToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AttendanceReportToolStripMenuItem.Click
        AttendanceReport.Close()
        AttendanceReport.ShowDialog()
    End Sub
End Class
