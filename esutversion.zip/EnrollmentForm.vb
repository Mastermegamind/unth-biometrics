Imports MySql.Data.MySqlClient
Imports System.IO


Public Class EnrollmentForm

    Public Data As AppData
    Dim counter As Integer = 0
    Dim mysqlconn As MySqlConnection
    Dim dr As MySqlDataReader
    Dim cmd As MySqlCommand
    Dim id As String

    Sub New(ByVal data As AppData)
        InitializeComponent()
        Me.Data = data
        ExchangeData(False)
        AddHandler data.OnChange, AddressOf OnDataChange

    End Sub

    Private Sub OnDataChange()
        ExchangeData(False)
    End Sub

    Public Sub ExchangeData(ByVal read As Boolean)
        If (read) Then
            Data.EnrolledFingersMask = EnrollmentControl.EnrolledFingerMask
            Data.MaxEnrollFingerCount = EnrollmentControl.MaxEnrollFingerCount
            Data.Update()
        Else
            EnrollmentControl.EnrolledFingerMask = Data.EnrolledFingersMask
            EnrollmentControl.MaxEnrollFingerCount = Data.MaxEnrollFingerCount
        End If
    End Sub

    Sub EnrollmentControl_OnEnroll(ByVal Control As Object, ByVal Finger As Integer, ByVal Template As DPFP.Template, ByRef EventHandlerStatus As DPFP.Gui.EventHandlerStatus) Handles EnrollmentControl.OnEnroll
        If (Data.IsEventHandlerSucceeds) Then
            Data.Templates(Finger - 1) = Template
            ExchangeData(True)
            ListEvents.Items.Insert(0, String.Format("OnEnroll: finger {0}", Finger))
            saveme(Finger, Template)
            counter += 1
        Else
            EventHandlerStatus = DPFP.Gui.EventHandlerStatus.Failure
        End If
    End Sub

    Sub EnrollmentControl_OnDelete(ByVal Control As Object, ByVal Finger As Integer, ByRef EventHandlerStatus As DPFP.Gui.EventHandlerStatus) Handles EnrollmentControl.OnDelete
        If (Data.IsEventHandlerSucceeds) Then
            Data.Templates(Finger - 1) = Nothing
            ExchangeData(True)
            ListEvents.Items.Insert(0, String.Format("OnDelete: finger {0}", Finger))
            counter -= 1
            deleteprint(Finger, Data.EnrolledFingersMask)
        Else
            EventHandlerStatus = DPFP.Gui.EventHandlerStatus.Failure
        End If
    End Sub

    Private Sub EnrollmentControl_OnCancelEnroll(ByVal Control As System.Object, ByVal ReaderSerialNumber As System.String, ByVal Finger As System.Int32) Handles EnrollmentControl.OnCancelEnroll
        ListEvents.Items.Insert(0, String.Format("OnCancelEnroll: {0}, finger {1}", ReaderSerialNumber, Finger))
    End Sub

    Private Sub EnrollmentControl_OnComplete(ByVal Control As System.Object, ByVal ReaderSerialNumber As System.String, ByVal Finger As System.Int32) Handles EnrollmentControl.OnComplete
        ListEvents.Items.Insert(0, String.Format("OnComplete: {0}, finger {1}", ReaderSerialNumber, Finger))
    End Sub

    Private Sub EnrollmentControl_OnFingerRemove(ByVal Control As System.Object, ByVal ReaderSerialNumber As System.String, ByVal Finger As System.Int32) Handles EnrollmentControl.OnFingerRemove
        ListEvents.Items.Insert(0, String.Format("OnFingerRemove: {0}, finger {1}", ReaderSerialNumber, Finger))
    End Sub

    Private Sub EnrollmentControl_OnFingerTouch(ByVal Control As System.Object, ByVal ReaderSerialNumber As System.String, ByVal Finger As System.Int32) Handles EnrollmentControl.OnFingerTouch
        ListEvents.Items.Insert(0, String.Format("OnFingerTouch: {0}, finger {1}", ReaderSerialNumber, Finger))
    End Sub

    Private Sub EnrollmentControl_OnReaderConnect(ByVal Control As System.Object, ByVal ReaderSerialNumber As System.String, ByVal Finger As System.Int32) Handles EnrollmentControl.OnReaderConnect
        ListEvents.Items.Insert(0, String.Format("OnReaderConnect: {0}, finger {1}", ReaderSerialNumber, Finger))
    End Sub

    Private Sub EnrollmentControl_OnReaderDisconnect(ByVal Control As System.Object, ByVal ReaderSerialNumber As System.String, ByVal Finger As System.Int32) Handles EnrollmentControl.OnReaderDisconnect
        ListEvents.Items.Insert(0, String.Format("OnReaderDisconnect: {0}, finger {1}", ReaderSerialNumber, Finger))
    End Sub

    Private Sub EnrollmentControl_OnSampleQuality(ByVal Control As System.Object, ByVal ReaderSerialNumber As System.String, ByVal Finger As System.Int32, ByVal CaptureFeedback As DPFP.Capture.CaptureFeedback) Handles EnrollmentControl.OnSampleQuality
        ListEvents.Items.Insert(0, String.Format("OnSampleQuality: {0}, finger {1}, {2}", ReaderSerialNumber, Finger, CaptureFeedback))
    End Sub

    Private Sub EnrollmentControl_OnStartEnroll(ByVal Control As System.Object, ByVal ReaderSerialNumber As System.String, ByVal Finger As System.Int32) Handles EnrollmentControl.OnStartEnroll
        ListEvents.Items.Insert(0, String.Format("OnStartEnroll: {0}, finger {1}", ReaderSerialNumber, Finger))
    End Sub

    Private Sub EnrollmentForm_FormClosing(sender As Object, e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing

        Main.loadenrolleddata()

    End Sub

    Private Sub EnrollmentForm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ListEvents.Items.Clear()
        'txtPersonId.Text = Form1.ComboBox1.SelectedItem
    End Sub

    Private Sub CloseButton_Click(sender As System.Object, e As System.EventArgs)

        'If counter <> 3 Then
        'MsgBox("3 different fingers need to be enrolled")
        'Else
        Me.Close()
        'Form1.Panel1.BackgroundImage = My.Resources.punchclock_app
        'End If

    End Sub

    Sub saveme(ByVal Finger As Integer, ByVal Templatee As DPFP.Template)
        Dim sup As Integer = 0

        Using checkConn As New MySqlConnection(Module1.ConnectionString)
            Using cmdCheck As New MySqlCommand("SELECT COUNT(*) FROM new_enrollment WHERE matricno = @matricno", checkConn)
                cmdCheck.Parameters.AddWithValue("@matricno", txtPersonId.Text.Trim())
                checkConn.Open()
                Dim result As Object = cmdCheck.ExecuteScalar()
                If result IsNot Nothing AndAlso result IsNot DBNull.Value Then
                    sup = Convert.ToInt32(result)
                End If
            End Using
        End Using

        Dim ms1 As New MemoryStream()
        Templatee.Serialize(ms1)
        Dim data As Byte() = ms1.ToArray()

        If sup > 0 Then
            Using mysqlconn As New MySqlConnection(Module1.ConnectionString)
                Using cmdUpdate As New MySqlCommand("UPDATE new_enrollment SET fingerdata" & Finger & " = @fingerdata, fingermask = @fingermask WHERE matricno = @matricno", mysqlconn)
                    cmdUpdate.CommandType = CommandType.Text
                    cmdUpdate.Parameters.AddWithValue("@matricno", txtPersonId.Text.Trim())
                    cmdUpdate.Parameters.AddWithValue("@fingermask", EnrollmentControl.EnrolledFingerMask)
                    cmdUpdate.Parameters.Add("@fingerdata", MySqlDbType.LongBlob).Value = data
                    mysqlconn.Open()
                    cmdUpdate.ExecuteNonQuery()
                End Using
            End Using
        Else
            Using mysqlconn As New MySqlConnection(Module1.ConnectionString)
                Using cmdInsert As New MySqlCommand("INSERT INTO new_enrollment (matricno, fingerdata" & Finger & ", fingermask) VALUES (@matricno, @fingerdata, @fingermask)", mysqlconn)
                    cmdInsert.CommandType = CommandType.Text
                    cmdInsert.Parameters.AddWithValue("@matricno", txtPersonId.Text.Trim())
                    cmdInsert.Parameters.AddWithValue("@fingermask", EnrollmentControl.EnrolledFingerMask)
                    cmdInsert.Parameters.Add("@fingerdata", MySqlDbType.LongBlob).Value = data
                    mysqlconn.Open()
                    cmdInsert.ExecuteNonQuery()
                End Using
            End Using
        End If
    End Sub


    Sub deleteprint(ByVal finger As Integer, ByVal fingermask As Object)
        Try
            Using mysqlconn As New MySqlConnection(Module1.ConnectionString)
                mysqlconn.Open()
                Using cmd1 As New MySqlCommand("UPDATE new_enrollment SET fingerdata" & finger & " = NULL WHERE matricno = @matricno", mysqlconn)
                    cmd1.Parameters.AddWithValue("@matricno", txtPersonId.Text.Trim())
                    cmd1.ExecuteNonQuery()
                End Using
                Using cmd2 As New MySqlCommand("UPDATE new_enrollment SET fingermask = @fingermask WHERE matricno = @matricno", mysqlconn)
                    cmd2.Parameters.AddWithValue("@matricno", txtPersonId.Text.Trim())
                    cmd2.Parameters.AddWithValue("@fingermask", Convert.ToInt32(fingermask))
                    cmd2.ExecuteNonQuery()
                End Using
            End Using
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub


    Sub loadfingeralreadytaken()
        Try
            Using mysqlconn As New MySqlConnection(Module1.ConnectionString)
                Using cmd As New MySqlCommand("SELECT fingermask FROM new_enrollment WHERE matricno = @matricno", mysqlconn)
                    cmd.Parameters.AddWithValue("@matricno", txtPersonId.Text.Trim())
                    mysqlconn.Open()
                    Dim result As Object = cmd.ExecuteScalar()
                    If result IsNot Nothing AndAlso result IsNot DBNull.Value Then
                        EnrollmentControl.EnrolledFingerMask = Convert.ToInt32(result)
                        Data.EnrolledFingersMask = Convert.ToInt32(result)
                    End If
                End Using
            End Using
        Catch ex As Exception

        End Try
    End Sub

    

    Private Sub EnrollmentForm_Shown(sender As Object, e As System.EventArgs) Handles Me.Shown
        loadfingeralreadytaken()
        'id = Form1.ComboBox1.SelectedItem
    End Sub

    'Protected Overridable Sub Process(ByVal Sample As DPFP.Sample)
    '    ConvertSampleToBitmap(Sample)
    'End Sub

    'Protected Function ConvertSampleToBitmap(ByVal Sample As DPFP.Sample) As Bitmap
    '    Dim convertor As New DPFP.Capture.SampleConversion()  ' Create a sample convertor.
    '    Dim bitmap As Bitmap = Nothing              ' TODO: the size doesn't matter
    '    convertor.ConvertToPicture(Sample, bitmap)

    '    Try
    '        Invoke(New FunctionCall(AddressOf _picturebox1draw), bitmap)
    '    Catch ex As Exception

    '    End Try

    '    Return bitmap
    'End Function

    'Sub _picturebox1draw(ByVal bmp)
    '    PictureBox1.Image = New Bitmap(bmp, 157, 168)
    'End Sub
End Class
